<?php 
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Check if the 'id' is passed in the URL (for editing a teacher)
if (isset($_GET['id'])) {
    $teacher_id = $_GET['id'];

    // Fetch teacher data from the database
    $stmt = $mysqli->prepare("SELECT * FROM teacher_registration WHERE id = ?");
    $stmt->bind_param("i", $teacher_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if teacher exists
    if ($result->num_rows > 0) {
        $teacher = $result->fetch_assoc();
    } else {
        echo "<div class='alert alert-danger'>Teacher not found!</div>";
        exit();
    }

    $stmt->close();
} else {
    echo "<div class='alert alert-danger'>No teacher ID provided!</div>";
    exit();
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<title>Edit Teacher</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			// On selecting a floor, fetch rooms using AJAX
			$('#floor_select').change(function() {
				var floor_id = $(this).val();
				if (floor_id) {
					$.ajax({
						type: 'POST',
						url: 'get_rooms.php', // A PHP file to fetch rooms based on floor_id
						data: { floor_id: floor_id },
						success: function(response) {
							$('#room_select').html(response); // Populate room dropdown
						}
					});
				} else {
					$('#room_select').html('<option value="">Select Room</option>');
				}
			});

			// Pre-select the floor and room
			var selectedFloor = "<?php echo $teacher['floor_id']; ?>";
			if (selectedFloor) {
				$('#floor_select').val(selectedFloor).trigger('change');
			}
			var selectedRoom = "<?php echo $teacher['room_number']; ?>";
			if (selectedRoom) {
				$('#room_select').val(selectedRoom);
			}
		});
	</script>
</head>
<body>
	<?php include('includes/header.php'); ?>
	<div class="ts-main-content">
		<?php include('includes/sidebar.php'); ?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Edit Teacher</h2>
						<div class="panel panel-primary">
							<div class="panel-heading">Edit Teacher Information</div>
							<div class="panel-body">
								<form method="post" action="update_teacher.php" class="form-horizontal" enctype="multipart/form-data">
									<div class="form-group">
										<label class="col-sm-4 control-label"><h4 style="color: green" align="left">Room Related Info</h4></label>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Full Name</label>
										<div class="col-sm-8">
											<input type="text" name="name" class="form-control" value="<?php echo $teacher['name']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Phone</label>
										<div class="col-sm-8">
											<input type="text" name="phone" class="form-control" value="<?php echo $teacher['phone']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Gender</label>
										<div class="col-sm-8">
											<select name="gender" class="form-control" required>
												<option value="Male" <?php echo ($teacher['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
												<option value="Female" <?php echo ($teacher['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">School</label>
										<div class="col-sm-8">
											<input type="text" name="school" class="form-control" value="<?php echo $teacher['school']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Panel (Subject)</label>
										<div class="col-sm-8">
											<input type="text" name="panel" class="form-control" value="<?php echo $teacher['panel']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Floor</label>
										<div class="col-sm-8">
											<select name="floor_id" id="floor_select" class="form-control" required>
												<option value="">Select Floor</option>
												<?php
												$floors = $mysqli->query("SELECT id, floor_name FROM floors");
												while ($floor = $floors->fetch_assoc()) {
													echo "<option value='{$floor['id']}'" . ($floor['id'] == $teacher['floor_id'] ? ' selected' : '') . ">{$floor['floor_name']}</option>";
												}
												?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Room</label>
										<div class="col-sm-8">
											<select name="room_number" id="room_select" class="form-control" required>
												<option value="">Select Room</option>
												<!-- Room options will be populated here by AJAX -->
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Bed Number</label>
										<div class="col-sm-8">
											<input type="text" name="bed_number" class="form-control" value="<?php echo $teacher['bed_number']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Date of Reporting</label>
										<div class="col-sm-8">
											<input type="date" name="date_reporting" class="form-control" value="<?php echo $teacher['date_reporting']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Date of Checkout</label>
										<div class="col-sm-8">
											<input type="date" name="date_checkout" class="form-control" value="<?php echo $teacher['date_checkout']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Capture Picture</label>
										<div class="col-sm-8">
											<input type="file" name="picture" accept="image/*" capture="user" class="form-control">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">NECTA Letter Provided</label>
										<div class="col-sm-8">
											<input type="checkbox" name="has_necta_letter" value="1" <?php echo ($teacher['has_necta_letter'] == 1 ? 'checked' : ''); ?>> Yes
										</div>
									</div>
									<div class="col-sm-6 col-sm-offset-4">
										<button class="btn btn-default" type="reset">Cancel</button>
										<input type="submit" name="submit" value="Update Teacher" class="btn btn-primary">
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>