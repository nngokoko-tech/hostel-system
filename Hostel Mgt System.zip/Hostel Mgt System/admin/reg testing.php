<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Code for registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $school = $_POST['school'];
    $panel = $_POST['panel'];
    $floor_id = $_POST['floor_id'];
    $room_number = $_POST['room_number'];  // Room number instead of room_id
    $bed_number = $_POST['bed_number'];
    $date_reporting = $_POST['date_reporting'];
    $date_checkout = $_POST['date_checkout'];
    $has_necta_letter = isset($_POST['has_necta_letter']) ? 1 : 0;

	if (isset($_POST['captured_image']) && !empty($_POST['captured_image'])) {
		$base64_string = $_POST['captured_image'];
	
		// Strip out the data:image/png;base64, part
		$base64_string = preg_replace('/^data:image\/\w+;base64,/', '', $base64_string);
	
		// Decode the base64
		$imageData = base64_decode($base64_string);
	
		// Save image to upload folder
		$picture_filename = 'upload/teacher_' . time() . '.png';
	
		// Ensure the upload directory exists
		if (!file_exists('upload')) {
			mkdir('upload', 0755, true);
		}
	
		file_put_contents($picture_filename, $imageData);
	
		// Save path to DB
		$picture = $picture_filename;
	}
   

    // Prepare and execute the insert query to store room_number instead of room_id
	$stmt = $mysqli->prepare("INSERT INTO teacher_registration 
	(name, phone, gender, school, panel, floor_id, room_number, bed_number, date_reporting, date_checkout, picture, has_necta_letter)
	VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	
	$stmt->bind_param("sssssiissssi",
		$name, $phone, $gender, $school, $panel, $floor_id,
		$room_number, $bed_number, $date_reporting, $date_checkout,
		$picture, $has_necta_letter);

		if (file_exists($picture_filename)) {
			echo "<div class='alert alert-info'>Image saved to $picture_filename</div>";
		} else {
			echo "<div class='alert alert-danger'>Failed to save image.</div>";
		}

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Registration successful!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }

    $stmt->close();
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Teacher Registration</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
</head>
<body>
	<?php include('includes/header.php'); ?>
	<div class="ts-main-content">
		<?php include('includes/sidebar.php'); ?>
		<div class="content-wrapper"  style="margin-top: 80px;">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
					<h2 class="page-title">Teacher Registration</h2>
                    <div class="panel panel-primary">
                        <div class="panel-heading">Fill all Info</div>
                        <div class="panel-body">
							<div class="row">
								<!-- Left side: the form -->
								<div class="col-md-9">
									<form method="post" action="update-teacher.php" class="form-horizontal" enctype="multipart/form-data">
									<div class="form-group">
										<label class="col-sm-4 control-label"><h4 style="color: green" align="left">Room Related info</h4></label>
									</div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Full Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Phone</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="phone" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Gender</label>
                                    <div class="col-sm-8">
                                        <select name="gender" class="form-control" required>
                                            <option value="">Select Gender</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">School</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="school" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Panel (Subject)</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="panel" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Floor</label>
                                    <div class="col-sm-8">
                                        <select name="floor_id" id="floor_select" class="form-control" required>
                                            <option value="">Select Floor</option>
                                            <?php
                                            $floors = $mysqli->query("SELECT id, floor_name FROM floors");
                                            while ($floor = $floors->fetch_assoc()) {
                                                echo "<option value='{$floor['id']}'>{$floor['floor_name']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Room</label>
                                    <div class="col-sm-8">
                                        <select name="room_number" id="room_select" class="form-control" required>
                                            <option value="">Select Room</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Bed Number</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="bed_number" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Date of Reporting</label>
                                    <div class="col-sm-8">
                                        <input type="date" name="date_reporting" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Date of Checkout</label>
                                    <div class="col-sm-8">
                                        <input type="date" name="date_checkout" class="form-control" required>
                                    </div>
                                </div>

                               
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">NECTA Letter Provided</label>
                                    <div class="col-sm-8">
                                        <input type="checkbox" name="has_necta_letter" value="1"> Yes
                                    </div>
                                </div>
                                <div class="col-sm-6 col-sm-offset-4">
                                    <button class="btn btn-default" type="reset">Cancel</button>
                                    <input type="submit" name="submit" value="Register" class="btn btn-primary">
                                </div>
                            </form>
							 <!-- Camera Capture Section -->
							 </div> <!-- end col-md-9 -->

							<!-- Right side: the picture -->
							<div class="col-md-3 text-left"> 
							 <div class="form-group">
									<label class="col-sm-2 control-label">Capture Picture</label>
									<div class="col-sm-8">
										<video id="video" width="100%" height="240" autoplay></video>
										<canvas id="canvas" style="display:none;"></canvas>
										<img id="preview" src="#" alt="Preview" style="display:none; max-width: 100%; margin-top:10px;" />
										<input type="hidden" name="captured_image" id="captured_image">
										<br><br>
										<button type="button" class="btn btn-success" onclick="captureImage()">Capture</button>
										<button type="button" class="btn btn-info" onclick="previewImage()">Preview</button>
									</div>
								</div>
							</div> <!-- end row -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JS for camera capture -->
    <script>
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(stream) {
                document.getElementById('video').srcObject = stream;
            })
            .catch(function(error) {
                console.error("Camera access error:", error);
            });

			function captureImage() {
				const canvas = document.getElementById('canvas');
				const video = document.getElementById('video');
				const context = canvas.getContext('2d');

				canvas.width = video.videoWidth;
				canvas.height = video.videoHeight;
				context.drawImage(video, 0, 0, canvas.width, canvas.height);

				const imageData = canvas.toDataURL('image/png');
				document.getElementById('captured_image').value = imageData;

				alert("Picture captured!");
			}

			function previewImage() {
				const imageData = document.getElementById('captured_image').value;
				if (imageData) {
					const preview = document.getElementById('preview');
					preview.src = imageData;
					preview.style.display = 'block';
				} else {
					alert("Please capture the picture first.");
				}
			}



        // AJAX to load rooms by floor
        $(document).ready(function(){
            $('#floor_select').change(function(){
                var floorId = $(this).val();
                if (floorId != '') {
                    $.ajax({
                        url: 'get_rooms_by_floor.php',
                        method: 'POST',
                        data: {floor_id: floorId},
                        success: function(data){
                            $('#room_select').html(data);
                        },
                        error: function(xhr, status, error) {
                            console.error("AJAX error:", error);
                        }
                    });
                } else {
                    $('#room_select').html('<option value="">Select Room</option>');
                }
            });
        });
    </script>
</body>
</html>