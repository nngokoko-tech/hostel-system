<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input
    $name = htmlspecialchars($_POST['name']);
    $phone = htmlspecialchars($_POST['phone']);
    $gender = $_POST['gender'];
    $school = htmlspecialchars($_POST['school']);
    $panel = htmlspecialchars($_POST['panel']);
    $floor_id = intval($_POST['floor_id']);
    $room_id = intval($_POST['room_id']);
    $bed_number = intval($_POST['bed_number']);
    $date_reporting = $_POST['date_reporting'];
    $has_necta_letter = isset($_POST['has_necta_letter']) ? 1 : 0;
    $picture = '';

    // Handle captured image
    if (!empty($_POST['captured_image'])) {
        $base64_string = preg_replace('/^data:image\/\w+;base64,/', '', $_POST['captured_image']);
        $imageData = base64_decode($base64_string);

        if (!file_exists('upload')) {
            mkdir('upload', 0755, true);
        }

        $picture_filename = 'upload/teacher_' . time() . '.png';
        if (file_put_contents($picture_filename, $imageData)) {
            $picture = $picture_filename;
        }
    }

    // Insert into database
    $stmt = $mysqli->prepare("INSERT INTO teacher_registration 
        (name, phone, gender, school, panel, floor_id, room_number, bed_number, date_reporting, picture, has_necta_letter)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("sssssissssi", $name, $phone, $gender, $school, $panel, $floor_id, $room_id, $bed_number, $date_reporting, $picture, $has_necta_letter);

    if ($stmt->execute()) {
        // Mark bed as occupied
        $update_bed = $mysqli->prepare("UPDATE beds SET is_occupied = 1 WHERE room_id = ? AND bed_number = ?");
        $update_bed->bind_param("ii", $room_id, $bed_number);
        $update_bed->execute();
        $update_bed->close();

        header("Location: registration.php");
        exit();
    } else {
        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }

    $stmt->close();


    
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Teacher Registration</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<script src="js/jquery-1.11.3-jquery.min.js"></script>
</head>

<body>
<?php include('includes/header.php'); ?>
<div class="ts-main-content">
<?php include('includes/sidebar.php'); ?>
<div class="content-wrapper" style="margin-top:80px;">
<div class="container-fluid">

<div class="row">
<div class="col-md-12">
<h2 class="page-title">Teacher Registration</h2>
<div class="panel panel-primary">
<div class="panel-heading">Fill All Info</div>
<div class="panel-body">
<form method="post" action="registration.php" class="form-horizontal" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-6">
            <!-- Column 1 -->
            <div class="form-group">
                <label class="col-sm-4 control-label">Full Name</label>
                <div class="col-sm-8">
                    <input type="text" name="name" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-4 control-label">Phone</label>
                <div class="col-sm-8">
                    <input type="text" name="phone" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-4 control-label">Gender</label>
                <div class="col-sm-8">
                    <select name="gender" class="form-control" required>
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-4 control-label">School</label>
                <div class="col-sm-8">
                    <input type="text" name="school" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-4 control-label">Panel (Subject)</label>
                <div class="col-sm-8">
                    <input type="text" name="panel" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-4 control-label">Floor</label>
                <div class="col-sm-8">
                    <select name="floor_id" id="floor_select" class="form-control" required>
                        <option value="">Select Floor</option>
                        <?php
                        $floors = $mysqli->query("SELECT id, floor_name FROM floors");
                        while ($floor = $floors->fetch_assoc()) {
                            echo "<option value='{$floor['id']}'>{$floor['floor_name']}</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label">Room</label>
                <div class="col-sm-8">
                <select name="room_id" id="room_select" class="form-control" required>
                        <option value="">Select Room</option>
                </select>
              </div>
            </div>

            

        </div>

        <div class="col-md-6">
            <!-- Column 2 -->
            
            <div class="form-group">
                <label class="col-sm-4 control-label">Bed Number</label>
                <div class="col-sm-8">
                    <select name="bed_number" id="bed_select" class="form-control" required>
                        <option value="">Select Bed</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-4 control-label">Date of Reporting</label>
                <div class="col-sm-8">
                    <input type="date" name="date_reporting" class="form-control" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-4 control-label">NECTA Letter Provided</label>
                <div class="col-sm-8">
                    <input type="checkbox" name="has_necta_letter" value="1"> Yes
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-4 control-label">Capture Picture</label>
                <div class="col-sm-8">
                    <video id="video" width="50%" height="100" autoplay></video>
                    <canvas id="canvas" style="display:none;"></canvas>
                    <img id="preview" src="#" alt="Preview" style="display:none; max-width:50%; margin-top:10px;" />
                    <input type="hidden" name="captured_image" id="captured_image">
                    <br><br>
                    <button type="button" class="btn btn-success" onclick="captureImage()">Capture</button>
                    <button type="button" class="btn btn-info" onclick="previewImage()">Preview</button>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-sm-offset-4">
        <button class="btn btn-default" type="reset">Cancel</button>
        <input type="submit" name="submit" value="Register" class="btn btn-primary">
    </div>
</form>
</div> <!-- end panel-body -->
</div> <!-- end panel -->
</div> <!-- end col -->
</div> <!-- end row -->

</div> <!-- end container -->
</div> <!-- end content-wrapper -->

<!-- Camera JS -->
<script>
let video = document.getElementById('video');
let canvas = document.getElementById('canvas');
let preview = document.getElementById('preview');
let capturedImage = document.getElementById('captured_image');
let stream;

function startCamera() {
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(function(s) {
            stream = s;
            video.srcObject = stream;
            video.style.display = 'block';
            preview.style.display = 'none';
        })
        .catch(function(err) {
            console.error("Camera error:", err);
        });
}

function stopCamera() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
    }
}

function captureImage() {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    let dataURL = canvas.toDataURL('image/png');
    capturedImage.value = dataURL;
    preview.src = dataURL;
    preview.style.display = 'block';
    video.style.display = 'none';
    stopCamera();
}

function previewImage() {
    if (capturedImage.value) {
        preview.src = capturedImage.value;
        preview.style.display = 'block';
        video.style.display = 'none';
    }
}

window.addEventListener('load', startCamera);

// Load Rooms and Beds Dynamically
$(document).ready(function(){
    $('#floor_select').change(function(){
        var floorId = $(this).val();
        if (floorId) {
            $.ajax({
                url: 'get_rooms_by_floor_inregstration.php',
                method: 'POST',
                data: {floor_id: floorId},
                success: function(data){
                    $('#room_select').html(data);
                }
            });
        }
    });

    $('#room_select').change(function(){
        var roomId = $(this).val();
        if (roomId) {
            $.ajax({
                url: 'get_beds_by_room.php',
                method: 'POST',
                data: {room_id: roomId},
                success: function(data){
                    $('#bed_select').html(data);
                }
            });
        }
    });
});
</script>

</body>
</html>