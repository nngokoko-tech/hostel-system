<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Delete Room
if (isset($_GET['del'])) {
    $id = intval($_GET['del']);
    $stmt = $mysqli->prepare("DELETE FROM rooms1 WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $stmt->close();
    echo "<script>alert('Room deleted successfully');</script>";
    echo "<script>window.location.href='manage-rooms.php'</script>";
}
?>
<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <title>Manage Rooms</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include('includes/header.php'); ?>
<div class="ts-main-content">
    <?php include('includes/sidebar.php'); ?>
    <div class="content-wrapper"  style="margin-top: 80px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="page-title">Manage Rooms</h2>

                    <div class="panel panel-default">
                        <div class="panel-heading">Room List</div>
                        <div class="panel-body">
                            <table id="zctb" class="display table table-striped table-bordered" width="100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Floor</th>
                                        <th>Room No.</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
<?php
$sql = "SELECT rooms1.id, rooms1.room_number, floors.floor_name 
        FROM rooms1 
        LEFT JOIN floors ON rooms1.floor_id = floors.id 
        ORDER BY floors.floor_name ASC, rooms1.room_number ASC";

$result = $mysqli->query($sql);
$cnt = 1;
while ($row = $result->fetch_assoc()) {
?>
<tr>
    <td><?php echo $cnt; ?></td>
    <td><?php echo htmlentities($row['floor_name']); ?></td>
    <td><?php echo htmlentities($row['room_number']); ?></td>
    <td>
        <a href="edit-room.php?id=<?php echo $row['id']; ?>"><i class="fa fa-edit"></i></a>&nbsp;&nbsp;
        <a href="manage-rooms.php?del=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this room?');">
            <i class="fa fa-trash"></i>
        </a>
    </td>
</tr>
<?php
    $cnt++;
}
?>
                                </tbody>
                            </table>
                        </div>
                    </div><!-- panel -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        $('#zctb').DataTable();
    });
</script>
</body>
</html>