<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Check if the 'id' is passed in the URL (for editing a teacher)
if (isset($_GET['id'])) {
    $teacher_id = $_GET['id'];

    // Fetch teacher data from the database
    $stmt = $mysqli->prepare("
    SELECT t.*, r.room_number 
    FROM teacher_registration t 
    LEFT JOIN rooms1 r ON t.room_number = r.id 
    WHERE t.id = ?
");
    $stmt->bind_param("i", $teacher_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if teacher exists
    if ($result->num_rows > 0) {
        $teacher = $result->fetch_assoc();
    } else {
        echo "<div class='alert alert-danger'>Teacher not found!</div>";
        exit();
    }

    $stmt->close();
} else {
    echo "<div class='alert alert-danger'>No teacher ID provided!</div>";
    exit();
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	<title>Teacher Registration</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="js/validation.min.js"></script>
</head>
<body>
	<?php include('includes/header.php'); ?>
	<div class="ts-main-content">
		<?php include('includes/sidebar.php'); ?>
		<div class="content-wrapper" style="margin-top: 80px;">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Teacher Registration</h2>
						<div class="panel panel-primary">
							<div class="panel-heading">Fill all Info</div>
							<div class="panel-body">
							
									<form method="post" action="update-teacher.php" class="form-horizontal" enctype="multipart/form-data">
							<div class="row">
							<div class="col-md-6">
							<!-- Column 1 -->
									<div class="form-group">
										<label class="col-sm-4 control-label"><h4 style="color: green" align="left">Room Related info</h4></label>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">ID</label>
										<div class="col-sm-8">
										<input type="hidden" name="id" value="<?php echo $teacher['id']; ?>">
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Full Name</label>
										<div class="col-sm-8">
											<input type="text" name="name" class="form-control" value="<?php echo $teacher['name']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Phone</label>
										<div class="col-sm-8">
											<input type="text" name="phone" class="form-control" value="<?php echo $teacher['phone']; ?>" required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Gender</label>
										<div class="col-sm-8">
										<select name="gender" class="form-control" required>
											<option value="">Select Gender</option>
											<option value="Male" <?php if ($teacher['gender'] == 'Male') echo 'selected'; ?>>Male</option>
											<option value="Female" <?php if ($teacher['gender'] == 'Female') echo 'selected'; ?>>Female</option>
										</select>	
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">School</label>
										<div class="col-sm-8">
											<input type="text" name="school" class="form-control" value="<?php echo $teacher['school']; ?>"  required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Panel (Subject)</label>
										<div class="col-sm-8">
											<input type="text" name="panel" class="form-control" value="<?php echo $teacher['panel']; ?>"  required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Floor</label>
										<div class="col-sm-8">
											<select name="floor_id" id="floor_select" class="form-control" value="<?php echo $teacher['floor_id']; ?>"  required>
												<option value="">Select Floor</option>
												<?php
													$floors = $mysqli->query("SELECT id, floor_name FROM floors");
													while ($floor = $floors->fetch_assoc()) {
														$selected = ($floor['id'] == $teacher['floor_id']) ? 'selected' : '';
														echo "<option value='{$floor['id']}' $selected>{$floor['floor_name']}</option>";
													}
												?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Room</label>
										<div class="col-sm-8">
											<select name="room_number" id="room_select" class="form-control" value="<?php echo $teacher['room_number']; ?>" required>
											<option value="<?php echo $teacher['room_number']; ?>" selected><?php echo $teacher['room_number']; ?></option>
											</select>
										</div>
									</div>

								</div><!-- end col-md-6 -->
								<div class="col-md-6">
								<!-- Column 2 -->

									<div class="form-group">
										<label class="col-sm-2 control-label">Bed Number</label>
										<div class="col-sm-8">
											<input type="text" name="bed_number" class="form-control"  value="<?php echo $teacher['bed_number']; ?>"required>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-2 control-label">Date of Reporting</label>
										<div class="col-sm-8">
											<input type="date" name="date_reporting" class="form-control" value="<?php echo $teacher['date_reporting']; ?>"  required>
										</div>
									</div>
									
									
									<div class="form-group">
										<label class="col-sm-2 control-label">NECTA Letter Provided</label>
										<div class="col-sm-8">
											<input type="checkbox" name="has_necta_letter" value="1"> Yes
										</div>
									</div>
									
									<div class="col-sm-6 col-sm-offset-4">
    								<button class="btn btn-default" type="reset">Cancel</button>
   									 <button type="submit" name="update" class="btn btn-success">Update Teacher</button>
									</div>
								
								

									<!-- Right side: the picture -->
									<div class="form-group">
										<label>Current / New Picture:</label><br>

										<?php if (!empty($teacher['picture']) && file_exists($teacher['picture'])): ?>
											<img id="currentImage" src="<?php echo htmlspecialchars($teacher['picture']); ?>" width="200" height="200" style="object-fit:cover;border-radius:10px;box-shadow:0 0 6px rgba(0,0,0,0.2);">
										<?php else: ?>
											<img id="currentImage" src="no_image.png" width="200" height="200" style="object-fit:cover;border-radius:10px;box-shadow:0 0 6px rgba(0,0,0,0.2);">
										<?php endif; ?>

										<br><br>

										<video id="video" width="200" height="150" autoplay style="border-radius:10px;box-shadow:0 0 6px rgba(0,0,0,0.2);"></video><br>
										<button type="button" onclick="captureImage()" class="btn btn-primary btn-sm" style="margin-top:8px;">Capture New Photo</button>

										<canvas id="canvas" width="200" height="150" style="display:none;"></canvas>
										<input type="hidden" name="captured_image" id="captured_image">
									</div>
								</div> <!-- end row -->

								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

    <script>

// Access webcam
const video = document.getElementById('video');
navigator.mediaDevices.getUserMedia({ video: true })
.then(stream => {
    video.srcObject = stream;
})
.catch(error => {
    console.error('Error accessing webcam:', error);
});

function captureImage() {
    const canvas = document.getElementById('canvas');
    const context = canvas.getContext('2d');

    // Draw the current frame from video to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Convert canvas to base64 image
    const dataURL = canvas.toDataURL('image/png');
    document.getElementById('captured_image').value = dataURL;

    // Replace the image preview with captured one
    document.getElementById('currentImage').src = dataURL;
}



		$(document).ready(function(){
			$('#floor_select').change(function(){
				var floorId = $(this).val();

				if (floorId != '') {
					$.ajax({
						url: 'get_rooms_by_floor.php',
						method: 'POST',
						data: {floor_id: floorId},
						success: function(data){
							$('#room_select').html(data);
						},
						error: function(xhr, status, error) {
							console.error("AJAX error:", error);
						}
					 });
				} else {
					$('#room_select').html('<option value="">Select Room</option>');
				}
			});
		});
	</script>


</body>
</html>