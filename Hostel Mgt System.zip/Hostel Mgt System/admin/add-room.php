<?php
ession_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();
 
if($_POST['submit']) {

//$trmsaid = $_SESSION['trmsaid'];
$floor = $_POST['floor'];
$room_number = $_POST['room_number'];

        // Check if the room already has 4 members
$check_sql = "SELECT COUNT(*) as member_count FROM rooms1 WHERE floor_name=:floor AND room_number=:room_number";
$check_query = $dbh->prepare($check_sql);
$check_query->bindParam(':floor', $floor, PDO::PARAM_STR);
$check_query->bindParam(':room_number', $room_number, PDO::PARAM_INT);
$check_query->execute();
$result = $check_query->fetch(PDO::FETCH_ASSOC);

    if ($result['member_count'] < 4) { // Only allow if less than 4 members
            // Insert into the database
        $sql = "INSERT INTO rooms1(floor_name, room_number) VALUES(:floor, :room_number)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':floor', $floor, PDO::PARAM_STR);
        $query->bindParam(':room_number', $room_number, PDO::PARAM_INT);
        $query->execute();
        $LastInsertId = $dbh->lastInsertId();

        if ($LastInsertId > 0) {
             echo '<script>alert("Room assignment has been added.")</script>';
            echo "<script>window.location.href ='manage-rooms.php'</script>";
        } else {
                echo '<script>alert("Something went wrong. Please try again.")</script>';
            }
        } else {
            echo '<script>alert("This room is already full! Choose another room.")</script>';
        }
 }

?>

<!doctype html>
<html lang="en">
<head>
    <title> Add Room</title>
    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <?php include_once('includes/sidebar.php'); ?>
    <div id="right-panel" class="right-panel">
        <?php include_once('includes/header.php'); ?>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Room Assignment</strong></div>
                            <form name="" method="post" action="">
                                <div class="card-body card-block">
                                    <div class="form-group">
                                        <label for="floor" class="form-control-label">Select Floor</label>
                                        <select name="floor" class="form-control" required>
                                            <option value="">Choose Floor</option>
                                            <option value="1st Floor">1st Floor</option>
                                            <option value="2nd Floor">2nd Floor</option>
                                            <option value="3rd Floor">3rd Floor</option>
                                            <option value="4th Floor">4th Floor</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="room_number" class="form-control-label">Select Room</label>
                                        <select name="room_number" class="form-control" required>
                                            <option value="">Choose Room</option>
                                            <option value="101">Room 101</option>
                                            <option value="102">Room 102</option>
                                            <option value="103">Room 103</option>
                                            <option value="104">Room 104</option>
                                            <option value="105">Room 105</option>
                                        </select>
                                    </div>

                                    <p style="text-align: center;">
                                        <button type="submit" class="btn btn-primary btn-sm" name="submit">
                                            <i class="fa fa-dot-circle-o"></i> Add
                                        </button>
                                    </p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div><!-- .animated -->
            </div><!-- .content -->
        </div><!-- /#right-panel -->
    </div>

    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
</html>
