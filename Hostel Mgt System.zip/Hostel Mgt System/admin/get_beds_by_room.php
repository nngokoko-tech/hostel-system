<?php
include('includes/config.php');

if (isset($_POST['room_id'])) {
    $room_id = intval($_POST['room_id']);
    $stmt = $mysqli->prepare("SELECT bed_number, bed_name FROM beds WHERE room_id = ? AND is_occupied = 0");
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<option value=''>Select Bed</option>";
    while ($row = $result->fetch_assoc()) {
        echo "<option value='{$row['bed_number']}'>{$row['bed_name']}</option>";
    }

    $stmt->close();
}
?>