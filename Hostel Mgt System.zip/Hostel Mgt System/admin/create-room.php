<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Code for adding rooms manually by room number
if (isset($_POST['submit'])) {
    $floor = $_POST['floor_name'];
    $room_numbers = explode(',', $_POST['room_numbers']);
    $room_numbers = array_map('trim', $room_numbers);

    // Get floor_id
    $sql = "SELECT id FROM floors WHERE floor_name = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('s', $floor);  // Binding floor_name as a string
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($floor_id);
    $stmt->fetch();

    $inserted_count = 0;
    $duplicates = [];

    foreach ($room_numbers as $roomno) {
        // Don't use is_numeric for room number anymore as room_number can contain alphabets
        // Treat room number as a string directly

        // Check for existing room
        $sql_check = "SELECT room_number FROM rooms1 WHERE room_number = ? AND floor_id = ?";
        $stmt1 = $mysqli->prepare($sql_check);
        $stmt1->bind_param('si', $roomno, $floor_id);  // Binding roomno as string ('s') and floor_id as integer ('i')
        $stmt1->execute();
        $stmt1->store_result();

        if ($stmt1->num_rows > 0) {
            $duplicates[] = $roomno;
        } else {
            // Debugging: check floor_id and roomno
            echo "Inserting: Floor ID: $floor_id, Room Number: $roomno <br>";  // Debugging line
            
            $query = "INSERT INTO rooms1 (floor_id, room_number) VALUES (?, ?)";
            $stmt2 = $mysqli->prepare($query);
            $stmt2->bind_param('is', $floor_id, $roomno);  // Bind floor_id as integer ('i') and room_number as string ('s')
            
            if ($stmt2->execute()) {
                $inserted_count++;
            } else {
                echo "Error: " . $stmt2->error . "<br>";  // Error handling
            }
        }
    }

    if ($inserted_count > 0) {
        echo "<script>alert('$inserted_count room(s) added successfully.');</script>";
    }
    if (!empty($duplicates)) {
        $dup_str = implode(', ', $duplicates);
        echo "<script>alert('The following room(s) already exist and were skipped: $dup_str');</script>";
    }
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <title>Create Room</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('includes/header.php'); ?>
<div class="ts-main-content">
    <?php include('includes/sidebar.php'); ?>
    <div class="content-wrapper" style="margin-top: 80px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="page-title">Add Rooms</h2>

                    <div class="panel panel-default">
                        <div class="panel-heading">Add Rooms to Floor</div>
                        <div class="panel-body">
                            <form method="post" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Select Floor</label>
                                    <div class="col-sm-8">
                                        <select name="floor_name" class="form-control" required>
                                            <option value="">Choose Floor</option>
                                            <?php
                                            $sql = "SELECT * FROM floors";
                                            $result = $mysqli->query($sql);
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<option value='" . $row['floor_name'] . "'>" . $row['floor_name'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Room Numbers</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="room_numbers" class="form-control"
                                               placeholder="Enter room numbers separated by commas, e.g. A101, B102, C103"
                                               required>
                                    </div>
                                </div>

                                <div class="col-sm-8 col-sm-offset-2">
                                    <input class="btn btn-primary" type="submit" name="submit" value="Create Room(s)">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>