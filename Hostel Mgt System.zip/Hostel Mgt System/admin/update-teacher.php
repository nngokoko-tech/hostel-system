<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Check if the form is submitted via POST and the update button was clicked
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    // Retrieve and sanitize form data
    $teacher_id      = intval($_POST['id']);
    $name            = trim($_POST['name']);
    $phone           = trim($_POST['phone']);
    $gender          = trim($_POST['gender']);
    $school          = trim($_POST['school']);
    $panel           = trim($_POST['panel']);
    $floor_id        = trim($_POST['floor_id']);
    $room_number     = trim($_POST['room_number']);
    $bed_number      = trim($_POST['bed_number']);
    $date_reporting  = trim($_POST['date_reporting']);

    // Picture upload
    $new_picture = null;
    if (!empty($_POST['captured_image'])) {
        $imgData = $_POST['captured_image'];
        $imgData = str_replace('data:image/png;base64,', '', $imgData);
        $imgData = str_replace(' ', '+', $imgData);
        $decodedData = base64_decode($imgData);

        // Save new image
        $image_name = 'uploads/teacher_' . time() . '.png';
        if (file_put_contents($image_name, $decodedData)) {
            $new_picture = $image_name;
        }
    }

    if ($new_picture) {
        // If new picture uploaded, update with image
        $stmt = $mysqli->prepare("UPDATE teacher_registration SET 
            name = ?, phone = ?, gender = ?, school = ?, panel = ?, 
            floor_id = ?, room_number = ?, bed_number = ?, 
            date_reporting = ?, picture = ?
            WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ssssssssssi", $name, $phone, $gender, $school, $panel, $floor_id, $room_number, $bed_number, $date_reporting, $new_picture, $teacher_id);
        }
    } else {
        // If no new picture, don't update image field
        $stmt = $mysqli->prepare("UPDATE teacher_registration SET 
            name = ?, phone = ?, gender = ?, school = ?, panel = ?, 
            floor_id = ?, room_number = ?, bed_number = ?, 
            date_reporting = ?
            WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("sssssssssi", $name, $phone, $gender, $school, $panel, $floor_id, $room_number, $bed_number, $date_reporting, $teacher_id);
        }
    }

    if ($stmt) {
        if ($stmt->execute()) {
            header("Location: manage-teacher.php");
            exit();
        } else {
            echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
        $stmt->close();
    } else {
        echo "<div class='alert alert-danger'>Prepare failed: " . $mysqli->error . "</div>";
    }
}
?>