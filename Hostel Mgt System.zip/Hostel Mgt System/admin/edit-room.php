<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Update room if form submitted
if (isset($_POST['update'])) {
    $room_id = $_POST['room_id'];
    $new_room_number = $_POST['room_number']; // room number will now be a string
    $new_floor_name = $_POST['floor_name'];

    // Get floor ID
    $stmt = $mysqli->prepare("SELECT id FROM floors WHERE floor_name = ?");
    $stmt->bind_param("s", $new_floor_name);  // 's' for string (floor name is a string)
    $stmt->execute();
    $stmt->bind_result($floor_id);
    $stmt->fetch();
    $stmt->close();

    // Update room info
    $stmt = $mysqli->prepare("UPDATE rooms1 SET room_number = ?, floor_id = ? WHERE id = ?");
    $stmt->bind_param("ssi", $new_room_number, $floor_id, $room_id);  // 's' for room_number, 'i' for floor_id and room_id
    
    if ($stmt->execute()) {
        echo "<script>alert('Room updated successfully.');</script>";
    } else {
        echo "<script>alert('Update failed.');</script>";
    }
    $stmt->close();
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <title>Edit Room</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('includes/header.php'); ?>
<div class="ts-main-content">
    <?php include('includes/sidebar.php'); ?>
    <div class="content-wrapper" style="margin-top: 80px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="page-title">Edit Room</h2>

                    <div class="panel panel-default">
                        <div class="panel-heading">Modify Existing Room</div>
                        <div class="panel-body">
                            <form method="post" class="form-horizontal">
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Select Room</label>
                                    <div class="col-sm-8">
                                        <select name="room_id" class="form-control" required onchange="this.form.submit()">
                                            <option value="">Choose Room</option>
                                            <?php
                                            $res = $mysqli->query("SELECT rooms1.id, rooms1.room_number, floors.floor_name FROM rooms1 JOIN floors ON rooms1.floor_id = floors.id");
                                            while ($row = $res->fetch_assoc()) {
                                                $selected = (isset($_POST['room_id']) && $_POST['room_id'] == $row['id']) ? "selected" : "";
                                                echo "<option value='{$row['id']}' $selected>Room {$row['room_number']} - Floor {$row['floor_name']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <?php if (isset($_POST['room_id'])):
                                    $room_id = $_POST['room_id'];
                                    $stmt = $mysqli->prepare("SELECT room_number, floor_id FROM rooms1 WHERE id = ?");
                                    $stmt->bind_param("i", $room_id);
                                    $stmt->execute();
                                    $stmt->bind_result($room_number, $floor_id);
                                    $stmt->fetch();
                                    $stmt->close();

                                    // Get current floor name
                                    $stmt = $mysqli->prepare("SELECT floor_name FROM floors WHERE id = ?");
                                    $stmt->bind_param("i", $floor_id);
                                    $stmt->execute();
                                    $stmt->bind_result($floor_name);
                                    $stmt->fetch();
                                    $stmt->close();
                                ?>

                                <input type="hidden" name="room_id" value="<?= $room_id ?>">

                                <div class="form-group">
                                    <label class="col-sm-2 control-label">New Room Number</label>
                                    <div class="col-sm-8">
                                        <input type="text" name="room_number" class="form-control" value="<?= $room_number ?>" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-2 control-label">New Floor</label>
                                    <div class="col-sm-8">
                                        <select name="floor_name" class="form-control" required>
                                            <?php
                                            $floors = $mysqli->query("SELECT floor_name FROM floors");
                                            while ($f = $floors->fetch_assoc()) {
                                                $selected = ($f['floor_name'] == $floor_name) ? "selected" : "";
                                                echo "<option value='{$f['floor_name']}' $selected>{$f['floor_name']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-sm-8 col-sm-offset-2">
                                    <input class="btn btn-primary" type="submit" name="update" value="Update Room">
                                </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>