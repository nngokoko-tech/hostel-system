<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

if (isset($_GET['delete'])) {
    $teacher_id = $_GET['delete'];

    $stmt = $mysqli->prepare("DELETE FROM teacher_registration WHERE id = ?");
    $stmt->bind_param("i", $teacher_id);
    
    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Teacher record deleted successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }
    $stmt->close();
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <title>Manage Teacher Registrations</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-social.css">
    <link rel="stylesheet" href="css/bootstrap-select.css">
    <link rel="stylesheet" href="css/fileinput.min.css">
    <link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include('includes/header.php'); ?>
<div class="ts-main-content">
    <?php include('includes/sidebar.php'); ?>
    <div class="content-wrapper" style="margin-top: 80px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">

                    <h2 class="page-title">Manage Teacher Registrations</h2>
                    <!-- Print Button -->
                    <div style="margin-bottom: 20px;">
                        <button onclick="printContent()" class="btn btn-primary">Print All Teachers</button>
                    </div>
                    <div class="panel panel-primary">
                        <div class="panel-heading">Teacher List</div>
                        <div class="panel-body">
                            <table class="table table-bordered" id="teachersTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Gender</th>
                                        <th>School</th>
                                        <th>Panel</th>
                                        <th>Floor</th>
                                        <th>Room</th>
                                        <th>Bed Number</th>
                                        <th>Reporting Date</th>
                                        <th>Photo</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $stmt = $mysqli->query("SELECT t.*, r.room_number 
                                    FROM teacher_registration t
                                    LEFT JOIN rooms1 r ON t.room_number = r.id");
                                    while ($teacher = $stmt->fetch_assoc()) {
                                        echo "<tr>
                                            <td>{$teacher['id']}</td>
                                            <td>{$teacher['name']}</td>
                                            <td>{$teacher['phone']}</td>
                                            <td>{$teacher['gender']}</td>
                                            <td>{$teacher['school']}</td>
                                            <td>{$teacher['panel']}</td>";

                                        // Fetch Floor Name
                                        $floor_id = isset($teacher['floor_id']) ? $teacher['floor_id'] : null;
                                        if ($floor_id) {
                                            $floor_stmt = $mysqli->prepare("SELECT floor_name FROM floors WHERE id = ?");
                                            $floor_stmt->bind_param("i", $floor_id); 
                                            $floor_stmt->execute();
                                            $floor_result = $floor_stmt->get_result();

                                            if ($floor_result->num_rows > 0) {
                                                $floor = $floor_result->fetch_assoc();
                                                echo "<td>{$floor['floor_name']}</td>";
                                            } else {
                                                echo "<td>Floor not found</td>";
                                            }
                                            $floor_stmt->close();
                                        } else {
                                            echo "<td>No Floor ID</td>";
                                        }

                                        // Display Room Number from rooms1 table
                                        $room_number = isset($teacher['room_number']) ? $teacher['room_number'] : "No Room Number";
                                        echo "<td>{$room_number}</td>";

                                        echo "<td>{$teacher['bed_number']}</td>
                                            <td>{$teacher['date_reporting']}</td>";
                                        
                                        echo "<td>";
                                            if (!empty($teacher['picture']) && file_exists($teacher['picture'])) {
                                                echo "<img src='{$teacher['picture']}' width='60' height='60' style='object-fit:cover;border-radius:5px;'>";
                                            } else {
                                                echo "No photo";
                                            }
                                        echo "</td>";
                                        
                                        echo "<td>
                                                <a href='edit-teacher.php?id={$teacher['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                                <a href='manage-teacher.php?delete={$teacher['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this teacher?\")'>Delete</a>
                                                <button onclick='printIndividualRecord({$teacher['id']})' class='btn btn-info btn-sm'>Print</button> 
                                            </td>
                                        </tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div> <!-- /.panel-body -->
                    </div> <!-- /.panel -->
                </div> <!-- /.col-md-12 -->
            </div> <!-- /.row -->
        </div> <!-- /.container-fluid -->
    </div> <!-- /.content-wrapper -->
</div> <!-- /.ts-main-content -->

<!-- Scripts -->
<script src="js/jquery-1.11.3-jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>

<script>
function printContent() {
    // Clone the table
    var table = document.getElementById("teachersTable").cloneNode(true);

    // Remove the last column from the table header
    var ths = table.querySelectorAll("thead tr th");
    if (ths.length > 0) {
        ths[ths.length - 1].remove(); // Remove the "Actions" header
    }

    // Remove the last cell from each row in tbody
    var rows = table.querySelectorAll("tbody tr");
    rows.forEach(function(row) {
        row.removeChild(row.lastElementChild); // Remove the "Actions" column
    });

    // Open print window and write the modified table
    var printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Teacher Registrations</title>');
    printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } td, th { border: 1px solid #ccc; padding: 8px; }</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write(table.outerHTML);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
}

</script>

<!-- Print Individual Teacher Record -->
<script>
function printIndividualRecord(teacherId) {
    // Fetch individual teacher's record
    $.ajax({
        url: 'get-teacher-record.php', // A PHP file to fetch teacher's data by ID
        method: 'GET',
        data: {id: teacherId},
        success: function(response) {
            var printWindow = window.open('', '', 'height=600,width=800');
            printWindow.document.write('<html><head><title>Teacher Record</title></head><body>');
            printWindow.document.write(response); // Display the teacher's record in the new window
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }
    });
}
</script>

<script>
$(document).ready(function() {
    $('#teachersTable').DataTable();
});
</script>

</body>
</html>