<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				
						<li><a href="add-courses.php"><i class="fa fa-files-o"></i> Add Panel</a></li>
						<li><a href="manage-courses.php"><i class="fa fa-files-o"></i> Manage Panel</a></li>
						<li><a href="panel-report.php"><i class="fa fa-desktop"></i>Panel report</a></li>
				
				
					
						<li><a href="create-room.php" ><i class="fa fa-desktop"> </i> Add a room</a></li>
						<li><a href="manage-rooms.php"><i class="fa fa-desktop"></i>Manage Rooms</a></li>
						<li><a href="add_beds_by_rooms.php"><i class="fa fa-desktop"></i>Add Beds by rooms</a></li>
						
				

				<li><a href="registration.php"><i class="fa fa-user"></i>Teacher Registration</a></li>
				<li><a href="manage-teacher.php"><i class="fa fa-users"></i>Manage Teacher</a></li>
				<li><a href="checkout.php"><i class="fa fa-file"></i>CheckOut</a></li>

            </ul>
</nav>
