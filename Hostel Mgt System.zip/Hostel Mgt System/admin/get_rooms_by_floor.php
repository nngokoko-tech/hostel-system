<?php
include('includes/config.php');

if (isset($_GET['floor'])) {
    $floor_id = intval($_GET['floor']); // Use $_GET and 'floor'

    $query = "SELECT id, room_number FROM rooms1 WHERE floor_id = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("i", $floor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<option value=''>Select Room</option>";

    while ($room = $result->fetch_assoc()) {
        echo "<option value='{$room['id']}'>{$room['room_number']}</option>";
    }

    $stmt->close();
}
?>