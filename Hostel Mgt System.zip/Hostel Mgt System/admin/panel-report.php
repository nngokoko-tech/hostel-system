<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Code for adding rooms manually by room number
if (isset($_POST['submit'])) {
    $floor = $_POST['floor_name'];
    $room_numbers = explode(',', $_POST['room_numbers']);
    $room_numbers = array_map('trim', $room_numbers);

    // Get floor_id
    $sql = "SELECT id FROM floors WHERE floor_name = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param('s', $floor);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($floor_id);
    $stmt->fetch();

    $inserted_count = 0;
    $duplicates = [];

    foreach ($room_numbers as $roomno) {
        if (!is_numeric($roomno)) continue;
        $roomno = intval($roomno);

        $sql_check = "SELECT room_number FROM rooms1 WHERE room_number = ? AND floor_id = ?";
        $stmt1 = $mysqli->prepare($sql_check);
        $stmt1->bind_param('ii', $roomno, $floor_id);
        $stmt1->execute();
        $stmt1->store_result();

        if ($stmt1->num_rows > 0) {
            $duplicates[] = $roomno;
        } else {
            $query = "INSERT INTO rooms1 (floor_id, room_number) VALUES (?, ?)";
            $stmt2 = $mysqli->prepare($query);
            $stmt2->bind_param('ii', $floor_id, $roomno);
            $stmt2->execute();
            $inserted_count++;
        }
    }

    if ($inserted_count > 0) {
        echo "<script>alert('$inserted_count room(s) added successfully.');</script>";
    }
    if (!empty($duplicates)) {
        $dup_str = implode(', ', $duplicates);
        echo "<script>alert('The following room(s) already exist and were skipped: $dup_str');</script>";
    }
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <title>Create Room</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('includes/header.php'); ?>
<div class="ts-main-content">
    <?php include('includes/sidebar.php'); ?>
    <div class="content-wrapper" style="margin-top: 80px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="page-title">Add Rooms</h2>

                    <div class="panel panel-default">
                        <div class="panel-heading">Number of teachers arrived per panel</div>
                        <div class="panel-body">
                     <hr>
                        <h3>Arrived Teachers in Panels</h3>
								<?php
								$report = $mysqli->query("SELECT panel, COUNT(*) as count FROM teacher_registration GROUP BY panel");
								while ($row = $report->fetch_assoc()) {
									echo "<p><strong>{$row['panel']}:</strong> {$row['count']} teacher(s)</p>";
								} 
                                ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>