<?php 
session_start();
include('includes/config.php');

if (isset($_GET['id'])) {
    $teacher_id = $_GET['id'];

    $stmt = $mysqli->prepare("SELECT * FROM teacher_registration WHERE id = ?");
    $stmt->bind_param("i", $teacher_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($teacher = $result->fetch_assoc()) {

        // Fetch Floor Name
        $floor_name = "Not Assigned";
        if ($teacher['floor_id']) {
            $floor_stmt = $mysqli->prepare("SELECT floor_name FROM floors WHERE id = ?");
            $floor_stmt->bind_param("i", $teacher['floor_id']);
            $floor_stmt->execute();
            $floor_result = $floor_stmt->get_result();
            if ($floor_result->num_rows > 0) {
                $floor = $floor_result->fetch_assoc();
                $floor_name = $floor['floor_name'];
            }
            $floor_stmt->close();
        }

        // Fetch the actual room number from the rooms1 table
        $room_number = "Not Assigned";
        if ($teacher['room_number']) {
            $room_stmt = $mysqli->prepare("SELECT room_number FROM rooms1 WHERE id = ?");
            $room_stmt->bind_param("i", $teacher['room_number']); // Assuming room_number contains the room ID
            $room_stmt->execute();
            $room_result = $room_stmt->get_result();
            if ($room_result->num_rows > 0) {
                $room = $room_result->fetch_assoc();
                $room_number = $room['room_number']; // Get the room_number from rooms1
            }
            $room_stmt->close();
        }

        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Teacher Details</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 40px;
                }
                .container {
                    position: relative;
                    width: 100%;
                }
                .teacher-picture {
                    position: absolute;
                    top: 0;
                    right: 0;
                    width: 150px;
                    height: 150px;
                    object-fit: cover;
                    border: 1px solid #ccc;
                    border-radius: 10px;
                }
                .print-btn {
                    margin-bottom: 20px;
                }
            </style>
        </head>
        <body>
            <button class="print-btn" onclick="window.print()">🖨️ Print</button>
            <div class="container">
                <?php if (!empty($teacher['picture']) && file_exists($teacher['picture'])): ?>
                    <img src="<?php echo $teacher['picture']; ?>" class="teacher-picture" alt="Teacher Picture">
                <?php endif; ?>

                <h2>Teacher Details</h2>
                <p><strong>Name:</strong> <?php echo $teacher['name']; ?></p>
                <p><strong>Phone:</strong> <?php echo $teacher['phone']; ?></p>
                <p><strong>Gender:</strong> <?php echo $teacher['gender']; ?></p>
                <p><strong>School:</strong> <?php echo $teacher['school']; ?></p>
                <p><strong>Panel:</strong> <?php echo $teacher['panel']; ?></p>
                <p><strong>Floor:</strong> <?php echo $floor_name; ?></p>
                <p><strong>Room:</strong> <?php echo $room_number; ?></p> <!-- Display the actual room number -->
                <p><strong>Bed Number:</strong> <?php echo $teacher['bed_number']; ?></p>
                <p><strong>Reporting Date:</strong> <?php echo $teacher['date_reporting']; ?></p>
                
            </div>
        </body>
        </html>
        <?php
    } else {
        echo "<p>Teacher not found.</p>";
    }

    $stmt->close();
}
?>