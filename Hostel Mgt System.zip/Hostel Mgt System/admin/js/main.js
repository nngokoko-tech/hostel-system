$(document).ready(function () {
  // Initialize menu
  $(".ts-sidebar-menu li a").each(function () {
    if ($(this).next().length > 0) {
      $(this).addClass("parent");
    }
  });

  // Add "more" button
  var menux = $(".ts-sidebar-menu li a.parent");
  $('<div class="more"><i class="fa fa-angle-down"></i></div>').insertBefore(
    menux
  );

  // Handle menu item clicks
  $(".more").click(function () {
    $(this).parent("li").toggleClass("open");
  });

  // Prevent the parent links from navigating away
  $(".parent").click(function (e) {
    e.preventDefault();
    $(this).parent("li").toggleClass("open");
  });

  // Handle sidebar toggle (menu button)
  $(".menu-btn").click(function () {
    $("nav.ts-sidebar").toggleClass("menu-open");
  });

  // Handle other side menu interactions (optional)
  $(".ts-sidebar-menu li a").click(function () {
    // Close other open submenus
    $(this).next("ul").slideToggle();
    $(this).parent("li").siblings().find("ul").slideUp();
  });
});
