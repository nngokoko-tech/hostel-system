<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacher_id = $_POST['teacher_id'];
    $checkout_date = $_POST['checkout_date'];
    $reason = $_POST['reason'];
    $remarks = $_POST['remarks'];
    $recorded_by = $_SESSION['login']; // assuming admin login username is stored here

    $stmt = $mysqli->prepare("INSERT INTO teacher_checkout (teacher_id, checkout_date, reason, remarks, recorded_by) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $teacher_id, $checkout_date, $reason, $remarks, $recorded_by);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Checkout recorded successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
    }

    $stmt->close();
}
?>
<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <title>Create Room</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('includes/header.php'); ?>
<div class="ts-main-content">
    <?php include('includes/sidebar.php'); ?>
    <div class="content-wrapper" style="margin-top: 80px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="page-title">CheckOut</h2>

                    <div class="panel panel-default">
                        <div class="panel-heading">check teacher out</div>
                        <div class="panel-body">
<form method="post" action="checkout.php">
    <label>Teacher:</label>
    <select name="teacher_id" required>
        <option value="">Select Teacher</option>
        <?php
        $result = $mysqli->query("SELECT id, name FROM teacher_registration");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['id']}'>{$row['name']}</option>";
        }
        ?>
    </select><br><br>

    <label>Checkout Date:</label>
    <input type="date" name="checkout_date" required><br><br>

    <label>Reason:</label>
    <input type="text" name="reason"><br><br>

    <label>Remarks:</label>
    <textarea name="remarks"></textarea><br><br>

    <button type="submit" class="btn btn-danger">Confirm Checkout</button>
</form>
</div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>