<?php
include('includes/config.php');

if (isset($_POST['floor_id'])) {
    $floor_id = intval($_POST['floor_id']);
    $stmt = $mysqli->prepare("SELECT id, room_number FROM rooms1 WHERE floor_id = ?");
    $stmt->bind_param("i", $floor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<option value=''>Select Room</option>";
    while ($row = $result->fetch_assoc()) {
        echo "<option value='{$row['id']}'>{$row['room_number']}</option>";
    }

    $stmt->close();
}
?>