<?php
session_start();
include('includes/config.php');
include('includes/checklogin.php');
check_login();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_id = $_POST['room_id'];
    $num_beds = $_POST['num_beds'];
    $bed_names = $_POST['bed_names'];  // Array of bed names

    // Check if the room exists
    $checkRoomQuery = "SELECT id FROM rooms1 WHERE id = ?";
    $stmt = $mysqli->prepare($checkRoomQuery);
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Insert the specified number of beds for the selected room
        for ($i = 1; $i <= $num_beds; $i++) {
            // Check if the bed already exists
            $checkBedQuery = "SELECT id FROM beds WHERE room_id = ? AND bed_number = ?";
            $stmtCheckBed = $mysqli->prepare($checkBedQuery);
            $stmtCheckBed->bind_param("ii", $room_id, $i);
            $stmtCheckBed->execute();
            $stmtCheckBed->store_result();

            if ($stmtCheckBed->num_rows == 0) {
                // Get bed name from the array
                $bed_name = $bed_names[$i - 1];

                // Insert a new bed with the name
                $insertBedQuery = "INSERT INTO beds (room_id, bed_number, bed_name, is_occupied, teacher_id) VALUES (?, ?, ?, 0, NULL)";
                $stmtInsertBed = $mysqli->prepare($insertBedQuery);
                $stmtInsertBed->bind_param("iis", $room_id, $i, $bed_name);
                if ($stmtInsertBed->execute()) {
                    echo "Bed $i added successfully for Room $room_id with name $bed_name.<br>";
                } else {
                    echo "Error adding bed $i for Room $room_id.<br>";
                }
                $stmtInsertBed->close();
            }

            $stmtCheckBed->close();
        }
    } else {
        echo "Invalid room selected.";
    }

    $stmt->close();
}

// Fetch all floors for the form
$floorQuery = "SELECT DISTINCT floor_id FROM rooms1";
$floorsResult = $mysqli->query($floorQuery);
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Beds to Room</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<?php include('includes/header.php'); ?>
<div class="ts-main-content">
    <?php include('includes/sidebar.php'); ?>
    <div class="content-wrapper" style="margin-top: 80px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="page-title">Add Beds</h2>

                    <div class="panel panel-default">
                        <div class="panel-heading">Add Beds to Rooms</div>
                        <div class="panel-body">
                            <form action="add_beds_by_rooms.php" method="POST" class="form-horizontal">
                                <!-- Floor Selection -->
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Floor</label>
                                    <div class="col-sm-8">
                                        <select name="floor_id" id="floor" class="form-control" required>
                                            <option value="">Select Floor</option>
                                            <?php
                                            // Fetch floors from the floors table
                                            $floorsQuery = "SELECT id, floor_name FROM floors"; 
                                            $floorsResult = $mysqli->query($floorsQuery);

                                            while ($floor = $floorsResult->fetch_assoc()):
                                            ?>
                                                <option value="<?= $floor['id'] ?>"><?= $floor['floor_name'] ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- Room Selection -->
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Room</label>
                                    <div class="col-sm-8">
                                        <select name="room_id" id="room_id" class="form-control" required>
                                            <option value="">Select Room</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Number of Beds -->
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Number of Beds</label>
                                    <div class="col-sm-8">
                                        <input type="number" name="num_beds" class="form-control" min="1" required>
                                    </div>
                                </div>

                                <!-- Bed Name(s) Input -->
                                <div class="form-group" id="bedNamesContainer">
                                    <!-- Dynamic Bed Name Inputs will be appended here -->
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <button type="submit" class="btn btn-primary">Add Beds</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Add input fields dynamically based on number of beds selected
$('input[name="num_beds"]').on('input', function() {
    var numBeds = $(this).val();
    var container = $('#bedNamesContainer');
    container.empty();  // Clear previous inputs

    for (var i = 1; i <= numBeds; i++) {
        var inputHTML = '<div class="form-group">\
            <label class="col-sm-2 control-label">Bed ' + i + ' Name</label>\
            <div class="col-sm-8">\
                <input type="text" name="bed_names[]" class="form-control" placeholder="Enter name for Bed ' + i + '" required>\
            </div>\
        </div>';
        container.append(inputHTML);  // Append input field for each bed
    }
});

// Load rooms based on selected floor
$('#floor').on('change', function() {
    var floor = $(this).val();
    
    // If no floor is selected, clear the room dropdown
    if (floor == "") {
        $('#room_id').html('<option value="">Select Room</option>');
        return;
    }

    // Fetch rooms for the selected floor
    $.ajax({
        url: 'get_rooms_by_floor.php',  // Ensure this path is correct
        method: 'GET',
        data: { floor: floor },
        success: function(response) {
            $('#room_id').html(response);  // Update the room select options
        },
        error: function() {
            alert("Error fetching rooms. Please try again.");
        }
    });
});
</script>

</body>
</html>